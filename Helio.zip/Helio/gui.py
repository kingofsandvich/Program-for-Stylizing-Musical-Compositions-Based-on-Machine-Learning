from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QDesktopWidget, QMessageBox, QPushButton, QMainWindow, QWidget, QComboBox, QVBoxLayout, QHBoxLayout
import sys
import urllib.request
import json
import binascii
import os
import time

def get_host():
	try:
		with open("host.txt", "r") as f:
			return f.read()
	except:
		msg = QMessageBox()
		msg.setText("You can set host via creating host.txt (contains only url) in the folder of app executable.nSetting default host.")
		msg.setWindowTitle("Host selection")
		msg.exec_()
	return r"http://127.0.0.1:5000/"

def exit_with_message(app, message="Something went wrong!"):
	msg = QMessageBox()
	msg.setIcon(QMessageBox.Critical)
	msg.setText(message)
	msg.setWindowTitle("Error")
	msg.exec_()
	sys.exit(-1)

def get_stylyzed(app, host, model_selected, atob=True):
	try:
		# read tmp.mid as hex string
		with open("tmp.mid", "rb") as file:
			tmp = str(binascii.hexlify(file.read()))
			tmp = tmp[2:-1]
		req = {
			"model": model_selected,
			"AtoB": atob,
			"midi": tmp
		}
		data = json.dumps(req)
		
		# Make request
		headers = {'Content-Type':'application/json'}
		url = host + "style_model/apply"
		req = urllib.request.Request(url, data.encode('utf-8'), headers)

		resp = urllib.request.urlopen(req)
		resp = resp.read()
		resp = json.loads(resp)

		midi = resp['midi'].encode()
		res_path = "tmp_res.mid"
		with open(res_path, "wb") as file:
			file.write(binascii.unhexlify(midi))
		os.chmod(res_path, 0o777)

		# time.sleep(3)

		sys.exit(0)

	except Exception as e:
		exit_with_message(app, message=str(e))

def get_model_names(app, host):
	try:
		contents = urllib.request.urlopen(host + "style_model/get_all").read().decode('utf-8')
		json_obj = json.loads(contents)
		if "response" in json_obj:
			return json_obj["response"]
	except:
		pass
	exit_with_message(app, "Could not get available models from host: " + host)

def make_app():
	# create app with window
	app = QApplication(sys.argv)
	app.setStyle('macintosh')
	window = QMainWindow()
	
	host = get_host()
	model_names = get_model_names(app, host)
	
	window.setWindowTitle("Stylisation: " + host)
	width, height = 350, 80
	# centerPoint = QDesktopWidget().availableGeometry().center()
	# window.setGeometry(300,250, width, height)
	# window.moveCenter(centerPoint)
	window.setFixedSize(width, height)

	# make widgets 
	combo = QComboBox()
	combo.addItems(model_names)
	atob = QPushButton("A to B")
	atob.clicked.connect(lambda:get_stylyzed(app, host, combo.currentText(), True))
	btoa = QPushButton("B to A")
	btoa.clicked.connect(lambda:get_stylyzed(app, host, combo.currentText(), False))

	# add widgets to window
	layout = QHBoxLayout()
	window.layout = layout

	layout.addWidget(combo)
	layout.addWidget(atob)
	layout.addWidget(btoa)
	
	widget = QWidget()
	widget.setLayout(layout)
	window.setCentralWidget(widget)
	window.show()

	app.exec_()
	sys.exit(-1)#app.exec_()


make_app()

